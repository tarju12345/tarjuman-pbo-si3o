<h1 align="center">PROJEK APLIKASI ABSENSI (JAVA NETBEANS + MySQL)</h1>

## Detail Table DB
- user : id, username, password
- mhs : nim, nama, kls, prodi, jns_klmn, no_telp, mtkl_plhn1, mtkl_plhn2, mtkl_plhn3
- matkul : id_matkul, nama_matkul
- pertemuan : id_pertemuan, tgl
- absen : id_absen, nim, id_matkul, id_pertemuan, ket

## Link demo
silahkan ke link berikut [Youtube](https://youtu.be/saCZL2xAtl4?si=yi_77SM_FVyhRNMQ)
